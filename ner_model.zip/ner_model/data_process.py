def doc_slice(inputfile,outputfile,start,end):
    with open(inputfile,'r',encoding='utf-8') as f:
        doclist=f.readlines()
    with open(outputfile,'w',encoding='utf-8') as f:
        docslicelist=doclist[start:end]
        for doc in docslicelist:
            f.write(doc.strip()+'\n')

if __name__=='__main__':
    inputfile=r'D:\研究生文件\硕士毕业准备\论文实验\topmine-master-bert-v4\input\doc_111485.txt'
    outputfile='data/input/doc_0_50000.txt'
    doc_slice(inputfile,outputfile,0,50000)