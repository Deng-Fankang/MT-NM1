import tensorflow as tf
import re
from tensorflow import keras
from transformers import BertTokenizer

from model import BertNerModel,NerMetric

def predict(sentence,model,tokenizer,max_length):
    sentence=sentence.replace('-',' ').strip()
    sentence=sentence.replace('/',' ').strip()
    inputs=tokenizer(sentence,max_length=max_length,return_tensors='tf',truncation=True,padding=True)
    tokenid = list(tf.concat([tf.squeeze(inputs['input_ids']), \
                              tf.zeros(shape=max_length - inputs['input_ids'].shape[1], dtype=tf.int32)], \
                             axis=-1).numpy())
    attention_mask = list(tf.concat([tf.squeeze(inputs['attention_mask']), \
                                     tf.zeros(shape=max_length - inputs['attention_mask'].shape[1], dtype=tf.int32)], \
                                    axis=-1).numpy())
    token_type_id = [0] * max_length
    inputs={
        'input_ids':tf.convert_to_tensor([tokenid]),
        'attention_mask':tf.convert_to_tensor([attention_mask]),
        'token_type_ids':tf.convert_to_tensor([token_type_id])
    }
    pred=tf.squeeze(model.predict((inputs,tf.zeros(shape=(1,max_length)))))
    entid=[];j=0;phraselist=[]
    for i,_id in enumerate(pred):
        if i<j:
            continue
        if _id==1:
            entid.append(tokenid[i])
            j=i+1
            while j<len(pred) and pred[j]==2:
                entid.append(tokenid[j])
                j+=1
            tokenlist = tokenizer.convert_ids_to_tokens(entid)
            words=[[tokenlist[0]]]
            for token in tokenlist[1:]:
                if token[0]=='#':
                    words[-1].append(token.replace('#',''))
                else:
                    words.append([token])
            phrase=[]
            for wordlist in words:
                phrase.append(''.join(wordlist))
            phrase=' '.join(phrase)
            phraselist.append(phrase)
    return list(set(phraselist))

def dataset_ner(infile,outputfile,model,tokenizer,max_length):
    with open(infile,'r',encoding='utf-8') as f:
        textlist=f.readlines()
    with open(outputfile,'w',encoding='utf-8') as fw:
        for text in textlist:
            sentence_list = re.split('[.?!|]', text)
            sentence_list = list(filter(lambda x: x.strip() != '', sentence_list))
            phraselist=[]
            for sentence in sentence_list:
                phraselist+=predict(sentence,model,tokenizer,max_length)
            phraselist=list(set(phraselist))
            fw.write(';'.join(phraselist)+'\n')


if __name__=='__main__':
    model = BertNerModel('bert-base-uncased', 3, 768)
    model.compile(optimizer=keras.optimizers.Adam(0.00001), metrics=[NerMetric()])
    # model.load_weights('data/sourcedata/nerdata/bertsave/splitsave/ckpt_loss_0.89')
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    infile=r'D:\研究生文件\硕士毕业准备\论文实验\topmine-master-bert-v4\input\doc_111485.txt'
    outputfile='data/result/docKwOfBert_111485.txt'
    dataset_ner(infile,outputfile,model,tokenizer,200)
